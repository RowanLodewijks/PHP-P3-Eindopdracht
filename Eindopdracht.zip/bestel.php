<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bestelpagina</title>
    <link rel="stylesheet" href="assets/css/bestel.css">
</head>
<body>
    <div id="container">
        <div id="header">
            <a href="index.html"><img src="wireframes/logo2.png" id="logo"></a>
        </div>
        <div class="item">
            <form method="POST" action="bedankt.php">
                <h2>Bestel</h2>
                    Voornaam, tussenvoegsel, achternaam: <input type="text" name="voornaam" required>, <input type="text" name="tussenvoegsel">, <input type="text" name="achternaam" required><br>
                    Straat: <input type="text" required><br>
                    Huisnummer: <input type="text" required><br>
                    Postcode: <input type="text" required><br>
                    Woonplaats: <input type="text" required><br>
                    Telefoonnummer: <input type="text"><br>
                    E-mailadres: <input type="text" name="email" required><br>
                    Rekeningnummer: <input type="text" required><br><br>
                <input type="submit" class="submit" name="submit"><br>
            </form>
        </div>
        <div id="footer">
            <div id="footertext">
                © 10/01/2022 Rowan Lodewijks
            </div>
        </div>
    </div>
</body>
</html>
<?php


?>